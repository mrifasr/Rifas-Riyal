import React from 'react';

const Comp1 = () => <div>Comp1</div>;

export default Comp1;
